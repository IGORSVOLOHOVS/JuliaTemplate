using Pkg;
Pkg.add("SQLite")
Pkg.add("Profile")
Pkg.add("Coverage")
Pkg.add("Logging")
Pkg.add("SyslogLogging")
Pkg.add("PackageCompiler")
Pkg.add("Documenter")
Pkg.add("YAML")
