using Logging

logger = ConsoleLogger()

global_logger(logger)

@info "Log is working!"