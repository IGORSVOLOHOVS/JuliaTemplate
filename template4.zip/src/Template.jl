module Template

include("jl/jl.jl")


function main()
    print(config_name)
end

end