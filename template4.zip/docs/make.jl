using Documenter
# using Template

makedocs(sitename = "Template.jl", remotes = nothing)